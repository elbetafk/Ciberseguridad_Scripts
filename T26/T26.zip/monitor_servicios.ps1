﻿Get-Service | Select-Object Name, DisplayName, Status, StartType
