#Integrantes del equipo
#Diego Fernando Betancourt Soto 
#Luis Mael Treviño Mares
#Carlos Sebastian Barceinas Olascoaga
 
import py2exe 
from distutils.core import setup

setup(
    console=['execute_pyautogui.py'], 
)

